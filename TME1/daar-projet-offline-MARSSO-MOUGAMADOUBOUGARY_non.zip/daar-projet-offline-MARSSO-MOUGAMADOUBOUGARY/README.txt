Les codes sont en python, pour tester le code manuellement il faut lancer cette commande : 
python RegEx.py <motif regex> <chemin du texte>

Il y'a 2 tests, un fonctionnel et un de performance il suffit de les exécuter sans argument (à condition d'avoir le fichier babylone.txt et le code RegEx.py dans le même dossier que le test)